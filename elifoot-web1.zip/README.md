# eLiFoot Web Game

## Setup
```bash
npm install
npm run dev