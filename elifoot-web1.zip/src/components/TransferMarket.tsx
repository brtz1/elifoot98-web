import React from 'react';
import './TransferMarket.css';

const TransferMarket: React.FC = () => (
  <div className="transfer-market">
    <h3>Available Players</h3>
    {/* TODO: list players with buy/sell controls */}
  </div>
);

export default TransferMarket;